const isObject = item =>
  item && typeof item === "object" && !Array.isArray(item) && item !== null

const mergeDeep = (target, source) => {
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!target[key]) Object.assign(target, { [key]: {} })
        mergeDeep(target[key], source[key])
      } else {
        Object.assign(target, { [key]: source[key] })
      }
    })
  }
  return target
}

module.exports.isObject = isObject
module.exports.mergeDeep = mergeDeep
