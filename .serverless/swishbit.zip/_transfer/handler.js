const { requestSwish } = require("./requestSwish")

module.exports.endpoint = ({ queryStringParameters }, context, callback) => {
  requestSwish(queryStringParameters)
    .then(token =>
      callback(null, {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin" : "*",
        },
        body: token
      })
    )
    .catch(callback)
}
