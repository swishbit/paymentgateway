// const { endpoint } = require("../handler")
// const { requestSwish } = require("../requestSwish")


// console.log(endpoint({
//   queryStringParameters: {amount: 100, address: "foo"}
// }, {}, () => {}))
test("users should be able to make a swish payment and receive bitcoins to provided address", () => {
  // requestSwish({
  //   amount: 100,
  //   address: "foo",
  // }).then(token => {
  //   expect(typeof token).toEqual("string")
  //   done()
  // })
})

test("it should verify bitcoin address", () => {})

test("it should log the requested transaction", () => {})

test("it should ensure sufficient balance", () => {})

test("it should convert SEK/BTC", () => {})

test("it should calculate fee", () => {})

test("it should transfer to address", () => {
  // return SEK to user on error
})
